---
title: "About & Team"
meta_title: "About & Team"
description: "About Lumax"
draft: false
---

{{< columns >}}
{{< column >}}
####  {.mb-4}

Founded on principles of scientific rigor and lasting partnerships, we transform complex environmental data into actionable insights. Whether tracking wildlife populations, assessing habitat health or measuring snow depth, we provide the precision tools needed for informed decision making. We currently operate in Europe and North America, collaborating with ecologists, ML specialists, computer scientists, universities, research institutes, NGOs, businesses, and government agencies.
{{< /column >}}
{{< column >}}
![Lumax team in the field](/images/ThorEelke.jpg)
{{< /column >}}
{{< /columns >}}

---

## Team

As a team, we are bound by our love for nature and drive to harness technology for better environmental understanding. Our strength lies in integrating ecological knowledge, professional data capture techniques, and modern analytics to provide unique insights into environmental challenges in an efficient manner.

[Meet the full team →](/team/)
