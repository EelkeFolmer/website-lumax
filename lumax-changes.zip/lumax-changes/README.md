# Lumax website — wijzigingen

Vier bestanden. Hieronder staat exact wat je per bestand doet.

---

## 1. `config/_default/menus.en.toml`
**Actie: vervang het bestaande bestand volledig**

Wijzigingen:
- "Tools" toegevoegd tussen Themes (weight 3) en About (weight 4)
- "About" hernoemd naar "About & Team"
- "Team" verwijderd als aparte nav-knop
- Tools en "About & Team" ook toegevoegd aan footer

---

## 2. `content/english/tools/_index.md`
**Actie: nieuw bestand, map `tools/` aanmaken in `content/english/`**

Dit is de inhoudspagina voor de Tools sectie.
De opmaak komt van het nieuwe layout-bestand (zie hieronder).

---

## 3. `content/english/about/_index.md`
**Actie: vervang het bestaande bestand**

Zelfde About-tekst als voorheen, maar nu met de titel "About & Team"
en een korte Team-sectie onderaan met een link naar de bestaande Team-pagina.
De Team-pagina zelf blijft ongewijzigd — alleen de navigatieknop is samengevoegd.

---

## 4. `layouts/tools/list.html`
**Actie: nieuw bestand, map `layouts/tools/` aanmaken**

Dit is de Hugo-layout voor de Tools-pagina. Het gebruikt dezelfde
Tailwind CSS klassen als de rest van de site (row, col, btn, section, container).
De drie tools worden getoond met afbeelding + tekst + link,
afwisselend links en rechts (zoals op de homepage).

Afbeeldingen die gebruikt worden (staan al in de repo):
- AI-BIRD:       `/images/AIBIRD_portal_hu8198447385398248369.png`
- SalmonVision:  `/images/salmonvision_hu7657966002911416383.png`
- CODAP:         `/images/AIBIRD_portal_hu11745037953255307095.png`
  (vervang dit later door een echte CODAP screenshot als die beschikbaar is)

---

## Samenvatting van alle te wijzigen bestanden

| Bestand | Actie |
|---|---|
| `config/_default/menus.en.toml` | Vervangen |
| `content/english/about/_index.md` | Vervangen |
| `content/english/tools/_index.md` | Nieuw aanmaken |
| `layouts/tools/list.html` | Nieuw aanmaken |

De bestaande `content/english/team/_index.md` en de Team-pagina
blijven volledig ongewijzigd — de pagina bestaat nog steeds op `/team`,
alleen de aparte navigatieknop is weg.
